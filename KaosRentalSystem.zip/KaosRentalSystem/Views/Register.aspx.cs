﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


namespace KaosRentalSystem.Views
{
    public partial class Register : System.Web.UI.Page
    {
        Models.Functions Conn;
        protected void Page_Load(object sender, EventArgs e)
        {
            

            Conn = new Models.Functions();
        }

        public override void VerifyRenderingInServerForm(Control control)
        {

        }

        protected void SaveBtn_Click(object sender, EventArgs e)
        {
            try
            {


                if (CustNameTb.Value == "" || PhoneTb.Value == "" || PasswordTb.Value == "" || AddTb.Value == "")

                {
                    ErrorMsg.InnerText = "Missing Information";
                }
                else
                {

                    string CustName = CustNameTb.Value;
                    string CustAdd = AddTb.Value;
                    string CustPhone = PhoneTb.Value;
                    string CustPass = PasswordTb.Value;
                    cheackAlreadyUsernameExist();
                    string Query = "insert into CustomerTbl values ('{0}','{1}','{2}','{3}')";
                    Query = String.Format(Query, CustName, CustAdd, CustPhone, CustPass);
                    Conn.SetData(Query);
                    ErrorMsg.InnerText = "Register Successful , directing Login Page in 3 Seconds";
                    Response.AddHeader("REFRESH", "3;URL=Login.aspx");

                }
            }
            catch (Exception Ex)
            {
                // throw;
                ErrorMsg.InnerText = Ex.Message;
            }
        }

        private void cheackAlreadyUsernameExist()
        {
          try
             {
                string custnametemp = CustNameTb.Value;                
                string checkuser = "SELECT count(*) FROM CustomerTbl where CustName=";
                Conn.SetData(checkuser);
                if(checkuser == custnametemp)
                {
                ErrorMsg.InnerText = "Username Already Exist";
                Response.AddHeader("REFRESH", "1;URL=Register.aspx");                 
                }                


             }
            catch (Exception Ex)
            {
                // throw;
                ErrorMsg.InnerText = Ex.Message;
            }
        }
        

        protected void Login_Click(object sender, EventArgs e)
        {
            Response.AddHeader("REFRESH", "0;URL=Login.aspx");
            
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KaosRentalSystem.Views.Customer
{
    public partial class Cars : System.Web.UI.Page
    {
        Models.Functions Conn;
        public override void VerifyRenderingInServerForm(Control control)
        {

        }

        private void ShowCars()
        {
            String St = "Available";
            string Query = "select * from CarTbl where Status= '"+St+"'";
            CarList.DataSource = Conn.GetData(Query);
            CarList.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            Conn = new Models.Functions();
            ShowCars();

        }
    }
}